/*******************************************************************************
 sortwords.h
*******************************************************************************/
#define FILE_OK       -1 /* If the file was opened successfully         */
#define FILE_ERR_OPEN -2 /* If the file was unable to be opened         */

#define MAX_WORDS 200000
#define LONGEST_WORD 50

int get_words(const char *filename, char *words[]);
void sort_words(char *words[], int count);
void print_words(char *words[], int count);
void free_words(char *words[], int count);
