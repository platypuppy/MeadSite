/*******************************************************************************
 main.c
*******************************************************************************/
#include <stdio.h> 
#include "sortwords.h"

void test_sort(void)
{
  int array[] = {5, 6, 2, 7, 3, 9, 3, 1, 6, 4, 5, 0, 2, 4};
  int size = sizeof(array) / sizeof(*array);
  int i, j;

  /* 
   * Write code to sort the array by comparing each element 
   * to every other element (in a nested loop).
   */

  /* 
    For each element in the array (call it X)
      For each element to the right of X (call it Y)
        If X > Y Then
          swap X and Y
        End If
      End For
    End For
   */
}

int main(int argc, char *argv[])
{
  const char *filename;   /* The file to open */
  char *words[MAX_WORDS]; /* All of the words read in */
  int count;              /* How many words read in   */

    /* Make sure the user specified an argument on the command line */
  if (argc < 2)
  {
    printf("Please specify a file of words to sort.\n");
    return -1;
  }

    /* The parameter is our file to sort */
  filename = argv[1]; 

    /* Read in all of the words from the file */
  count = get_words(filename, words);
  if (count == FILE_ERR_OPEN)
  {
    printf("Can't open %s\n", filename);
    return -1;
  }
    
  sort_words(words, count);  /* Sort the words in alphabetical order    */
  print_words(words, count); /* Print the sorted words                  */
  free_words(words, count);  /* Free the memory allocated for the words */

  return 0;
}



