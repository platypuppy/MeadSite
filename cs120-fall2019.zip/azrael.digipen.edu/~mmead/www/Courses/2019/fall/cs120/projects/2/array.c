void reverse_array(int a[], int size)
{
} 

void add_arrays(const int a[], const int b[], int c[], int size)
{
}

void scalar_multiply(int a[], int size, int multiplier)
{
}

int dot_product(const int a[], const int b[], int size)
{
}

void cross_product(const int a[], const int b[], int c[])
{
}
