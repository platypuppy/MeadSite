#include <stdio.h>     /* printf      */
#include <ctype.h>     /* toupper     */
#include <string.h>    /* strlen      */
#include "histogram.h" /* lab defines */

int GetCounts(const char *sentence, int letters[], int *spaces, int *other)
{
}

void PrintHistogram(const int letters[])
{
}

void GetStatistics(const int letters[], double *average, char *max_letter, 
                   int *max_count)
{
}

