#include <stddef.h> /* NULL */

const char *find_byte(const char *from, const char *to, char byte)
{
}

const char *find_any_byte(const char *from, const char *to, const char *set, 
                          int count)
{
}

int count_bytes(const char *from, const char *to, char byte)
{
}

int count_any_bytes(const char *from, const char *to, char *bytes, int count)
{
}

int compare_bytes(const char *location1, const char *location2, int count)
{
}

void exchange_bytes(char *p1, char *p2, int length)
{
}

void copy_bytes(char *from, char *to, int length)
{
}
