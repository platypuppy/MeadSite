#include <stdio.h> /* printf, scanf       */
#include "PRNG.h"  /* ut_srand, RandomInt */

int main(void)
{
    /* Define your variables here. */


    /* Seed the pseudo-random number generator.                   */
    /* DON'T CHANGE THIS WHEN UPLOADING TO THE SUBMISSION SERVER! */
    /* If you change this, your output won't match when you diff. */
  ut_srand(0, 0);

  do
  {
    /* You may also define variables here, if you need to. */


    /* Write your code here */


  } while (/* some expression */);

  return 0;
}
