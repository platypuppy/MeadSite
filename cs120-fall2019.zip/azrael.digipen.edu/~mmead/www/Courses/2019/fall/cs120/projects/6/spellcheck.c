/*******************************************************************************
  FILE HEADER TO BE COMPLETED BY THE STUDENT
*******************************************************************************/
#include <string.h> /* To be completed by the student       */
#include <stdio.h>  /* FILE (To be completed by the student */

/* FILE_OK, FILE_ERR_OPEN, WORD_OK, WORD_BAD, LONGEST_WORD */
#include "spellcheck.h"

